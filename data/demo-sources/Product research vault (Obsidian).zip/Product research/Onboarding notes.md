# Onboarding notes

New workspaces with more than 50 dashboards feel slow: the overview page can take 40 to 60 seconds to load.

Admins asked twice for a way to set how long SSO sessions last before users are signed out.

![[onboarding-flow.png]]
