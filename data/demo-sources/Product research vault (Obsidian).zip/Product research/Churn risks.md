---
tags: [churn, research]
updated: 2026-09-20
---
# Churn risks

Accounts that mentioned leaving this quarter: [[Brightline Freight]], [[Kestrel Health|Kestrel]], [[Halcyon Bank]].

- Brightline: export limit and wrong-currency invoices are both blockers for their January renewal.
- Kestrel: needs full exports for a November audit; otherwise they will evaluate other tools.
- Halcyon: branch managers keep getting logged out by SSO every 30 minutes.

%% TODO: add ARR for each account %%
