# Integrations

Slack is the most used integration. Several customers say Slack alerts arrive hours late or not at all, so they fall back to email.
