# Finance team feedback

Collected from three finance leads in September.

- Invoices show USD even when the contract is in EUR or GBP.
- The VAT number is missing from invoices, so accounts payable rejects them.
- Month-end exports are cut off at 1,000 rows, so totals never reconcile.

See also [[Churn risks]].
